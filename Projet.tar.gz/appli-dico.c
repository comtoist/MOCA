#include "affichage.h"
#include "dico.h"


int main(int argc, char* argv[])
{
  if(argc != 2){
    fprintf(stderr, "Il faut un nom de fichier texte\n");
    exit(BADARGNUMBER);
  }

  FILE* f = fopen(argv[1], "r");
  if(f == NULL){
    fprintf(stderr, "bad entry file \n");
    exit(OPENFILEERROR);
  }

  unsigned int* line = (unsigned int*) malloc(sizeof(int));
  unsigned int* colonne = (unsigned int*) malloc(sizeof(int));
  char* word = (char*) malloc(sizeof(char)*maxSizeWord);
  dico* dictionary = (dico*) malloc(sizeof(dico));
  while(!feof(f)) {
    word = next_word(f,line,colonne);
    addToDico(dictionary,word,line,colonne);
  }
  displayDico(dictionary);
  fclose(f);
  return 0;
}
