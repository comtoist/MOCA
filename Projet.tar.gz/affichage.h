#ifndef _TYPES_
#define _TYPES_

#include "types.h"

#endif

#ifndef _AFFICHAGE_
#define _AFFICHAGE_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "maillon.h"

void displayWord(mot_t* word, FILE *filedes);

void displayDico(dico* dictionary);

#endif
