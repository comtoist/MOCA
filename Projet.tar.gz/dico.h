#ifndef _TYPES_
#define _TYPES_

#include "types.h"

#endif

#ifndef _DICO_
#define _DICO_


#include "maillon.h"

void insertDico(dico* dictionary, mot_t* linkWord);

void addToDico(dico* dictionary, char* word, unsigned int* line, unsigned int* colonne);

#endif
